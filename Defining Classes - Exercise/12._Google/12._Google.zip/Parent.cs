﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12._Google
{
    public class Parent
    {
        public string Name { get; set; }
        public string Birthday { get; set; }

        public Parent(string name, string birthday)
        {

        }
    }
}
