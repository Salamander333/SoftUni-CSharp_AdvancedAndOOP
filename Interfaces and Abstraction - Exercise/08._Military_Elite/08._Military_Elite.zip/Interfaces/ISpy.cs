﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08._Military_Elite.Interfaces
{
    interface ISpy
    {
        int CodeNumber { get; }
    }
}
