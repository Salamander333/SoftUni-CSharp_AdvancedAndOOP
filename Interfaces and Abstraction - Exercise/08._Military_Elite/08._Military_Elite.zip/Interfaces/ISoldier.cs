﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08._Military_Elite.Interfaces
{
    interface ISoldier
    {
        string ID { get; }

        string FirstName { get; }

        string LastName { get; }
    }
}
