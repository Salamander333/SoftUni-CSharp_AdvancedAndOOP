﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06._Birthday_Celebrations
{
    interface IIdentifiable
    {
        string Id { get; }
    }
}
