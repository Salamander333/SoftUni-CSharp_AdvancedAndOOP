﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Border_Control
{
    interface IIdentifiable
    {
        string Id { get; }
    }
}
