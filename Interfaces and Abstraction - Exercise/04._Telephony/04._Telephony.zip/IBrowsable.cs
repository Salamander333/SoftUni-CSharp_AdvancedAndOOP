﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Telephony
{
    interface IBrowsable
    {
        string BrowseWebsite(string website);
    }
}
