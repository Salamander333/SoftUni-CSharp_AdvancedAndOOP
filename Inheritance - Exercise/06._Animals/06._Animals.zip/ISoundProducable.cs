﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06._Animals
{
    interface ISoundProducable
    {
        string ProduceSound();
    }
}
