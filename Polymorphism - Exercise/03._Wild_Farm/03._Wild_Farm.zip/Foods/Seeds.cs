﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Wild_Farm.Foods
{
    class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
